# Enote
Aplicativo de notas e lembretes com um design singular

Veja ele funcionando:
https://enoteapp.vercel.app/
